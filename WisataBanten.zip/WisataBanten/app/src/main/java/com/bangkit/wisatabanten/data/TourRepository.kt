package com.bangkit.wisatabanten.data

import com.bangkit.wisatabanten.model.BantenTourism
import com.bangkit.wisatabanten.model.TourSource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map

class TourRepository {

    private val listTour = mutableListOf<BantenTourism>()

    init {
        if (listTour.isEmpty()) {
            TourSource.tours.forEach {
                listTour.add(BantenTourism(it, false))
            }
        }
    }


    fun getAllTour(): Flow<List<BantenTourism>> {
        return flowOf(listTour)
    }

    fun getTourById(tourId: String): Flow<BantenTourism> {
        return flowOf(
            listTour.first {
                it.tour.id == tourId
            }
        )
    }

    fun findTour(query: String): List<BantenTourism> {
        return listTour.filter {
            it.tour.title.contains(query, ignoreCase = true)
        }
    }

    fun getAllFavoriteTour(): Flow<List<BantenTourism>> {
        return flowOf(listTour).map { orderTour ->
            orderTour.filter { it.isFavorite }
        }
    }

    fun updateFavoriteTour(tourId: String, newState: Boolean): Flow<Boolean> {
        val index = listTour.indexOfFirst { it.tour.id == tourId }
        val result = if (index >= 0) {
            val tour = listTour[index]
            listTour[index] = tour.copy(tour = tour.tour, isFavorite = newState)
            true
        } else {
            false
        }
        return flowOf(result)
    }


    companion object {
        @Volatile
        private var instance: TourRepository? = null

        fun getInstance(): TourRepository =
            instance ?: synchronized(this) {
                TourRepository().apply {
                    instance = this
                }
            }
    }
}