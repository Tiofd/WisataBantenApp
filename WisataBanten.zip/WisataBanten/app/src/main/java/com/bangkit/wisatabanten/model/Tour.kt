package com.bangkit.wisatabanten.model

data class Tour(
    val id: String,
    val image: Int,
    val title: String,
    val description: String
)
