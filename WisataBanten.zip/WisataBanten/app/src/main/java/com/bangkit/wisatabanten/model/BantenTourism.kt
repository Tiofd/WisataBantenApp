package com.bangkit.wisatabanten.model

data class BantenTourism(
    val tour: Tour,
    val isFavorite: Boolean
)
